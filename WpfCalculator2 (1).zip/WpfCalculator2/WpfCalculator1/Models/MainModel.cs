﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfCalculator1.Models
{
    public class ModelMemory
    {
        public string Memory { get; set; } = default!;

    }
    public class ModelHistory
    {

        public string History { get; set; } = default!;

    }

}
