#using <mscorlib.dll>
[assembly: System::Runtime::Versioning::TargetFrameworkAttribute(L".NETCoreApp,Version=v5.0", FrameworkDisplayName=L".NET 5.0")];
